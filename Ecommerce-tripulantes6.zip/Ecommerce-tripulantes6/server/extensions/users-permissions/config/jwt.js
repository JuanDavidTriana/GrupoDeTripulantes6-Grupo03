module.exports = {
  jwtSecret: process.env.JWT_SECRET || '8b69446d-938a-4ea7-b360-c2b22fec4325'
};