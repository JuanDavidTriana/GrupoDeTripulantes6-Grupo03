# Ecommerce-Grupo89
#### Comandos para instalar node_modules

-  Abrir una terminal dentro de la carpeta del proyecto y ejecutar el comando npm install.
- Si todo esta correcto, deberá tener una nueva carpeta llamada “node_modules” en la estructura de su carpeta
- Este proceso se tiene que realizar en la carpeta client y en la caroeta server
